// firebase-init.js

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBJgwoXtuQBjxvjZNBaFaobgmVjVJNKgqM",
  authDomain: "ascandane.firebaseapp.com",
  projectId: "ascandane",
  storageBucket: "ascandane.appspot.com",
  messagingSenderId: "389414086414",
  appId: "1:389414086414:web:e83f36f864afb41861595f",
  measurementId: "G-NMXHWJ4GRJ"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
